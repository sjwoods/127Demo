# Calculator

## Instructions

* Using the Spreadsheet and Unsolved VBS code as a starter, complete the script such that `Price`, `Tax`, `Quantity`, and `Total` are stored in variables.

* These variables should be then assigned the value of the cell they are associated with in the spreadsheet.

* When finished, your code should set the `Total` value in the spreadsheet and print a message box with the total in the form of: "Your total is $45.00"

## Bonus

* Try to complete the exercise, _without_ looking at the starter code.
