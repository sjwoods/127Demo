# Chess Board

## Instructions

* Populate the Chess Board provided with text-based chess pieces. For the top-half of the chess board use Ranges, for the bottom-half of the chess board use Cells.

## Hint

* Remember that with `Ranges`, it is possible to modify multiple cells at once.
